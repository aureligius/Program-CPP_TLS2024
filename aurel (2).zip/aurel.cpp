#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int km;
    string choice;
    
    cout << "Choose conversion: hm, dam, m, dm, cm, mm\n";
    cin >> choice;
    cout << "Enter km: ";
    cin >> km;
    
    if (choice == "hm") {
        cout << km << " in hectometer is " << km * 10 << " hm";
    }else if(choice == "dam"){
    cout << km << " in decameter is " << km *100 << " dam";
    }else if(choice == "m"){
    cout << km << " in meter is " << km * 1000 << " m";
    }else if(choice == "dm"){
    cout << km << " in desimeter is " << km * 10000 << " dm";
    }else if(choice == "cm"){
    cout << km << " in centimeter is " << km * 100000 << " cm";
    }else if(choice == "mm"){
    cout << km << " in milimeter is " << km * 1000000 << " mm";
    }
    
    return 0;
}