#include <iostream>
#include <iomanip> // For setting precision

int main() {
    // Input: distance in kilometers
    double kilometers;
    std::cout << "Enter distance in kilometers: ";
    std::cin >> kilometers;

    // Perform conversions
    double hectometers = kilometers * 10;
    double decameters = kilometers * 100;
    double meters = kilometers * 1000;
    double decimeters = kilometers * 10000;
    double centimeters = kilometers * 100000;
    double millimeters = kilometers * 1000000;

    // Output results with appropriate precision
    std::cout << std::fixed << std::setprecision(2); // Set precision for output

    std::cout << "Distance in hectometers (hm): " << hectometers << " hm" << std::endl;
    std::cout << "Distance in decameters (dam): " << decameters << " dam" << std::endl;
    std::cout << "Distance in meters (m): " << meters << " m" << std::endl;
    std::cout << "Distance in decimeters (dm): " << decimeters << " dm" << std::endl;
    std::cout << "Distance in centimeters (cm): " << centimeters << " cm" << std::endl;
    std::cout << "Distance in millimeters (mm): " << millimeters << " mm" << std::endl;

    return 0;

    return 0;
}